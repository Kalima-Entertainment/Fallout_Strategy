<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Deathclaw" tilewidth="160" tileheight="160" tilecount="625" columns="25">
 <image source="Deathclaw.png" width="4096" height="4096"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="100"/>
   <frame tileid="1" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="4" duration="100"/>
   <frame tileid="5" duration="100"/>
   <frame tileid="6" duration="100"/>
   <frame tileid="7" duration="100"/>
   <frame tileid="8" duration="100"/>
   <frame tileid="9" duration="100"/>
  </animation>
 </tile>
 <tile id="11">
  <animation>
   <frame tileid="11" duration="100"/>
   <frame tileid="12" duration="100"/>
   <frame tileid="13" duration="100"/>
   <frame tileid="14" duration="100"/>
   <frame tileid="15" duration="100"/>
   <frame tileid="16" duration="100"/>
   <frame tileid="17" duration="100"/>
   <frame tileid="18" duration="100"/>
  </animation>
 </tile>
 <tile id="25">
  <animation>
   <frame tileid="25" duration="100"/>
   <frame tileid="26" duration="100"/>
   <frame tileid="27" duration="100"/>
   <frame tileid="28" duration="100"/>
   <frame tileid="29" duration="100"/>
   <frame tileid="30" duration="100"/>
   <frame tileid="31" duration="100"/>
   <frame tileid="32" duration="100"/>
   <frame tileid="33" duration="100"/>
   <frame tileid="34" duration="100"/>
  </animation>
 </tile>
 <tile id="36">
  <animation>
   <frame tileid="36" duration="100"/>
   <frame tileid="37" duration="100"/>
   <frame tileid="38" duration="100"/>
   <frame tileid="39" duration="100"/>
   <frame tileid="40" duration="100"/>
   <frame tileid="41" duration="100"/>
   <frame tileid="42" duration="100"/>
   <frame tileid="43" duration="100"/>
  </animation>
 </tile>
 <tile id="50">
  <animation>
   <frame tileid="50" duration="100"/>
   <frame tileid="51" duration="100"/>
   <frame tileid="52" duration="100"/>
   <frame tileid="53" duration="100"/>
   <frame tileid="54" duration="100"/>
   <frame tileid="55" duration="100"/>
   <frame tileid="56" duration="100"/>
   <frame tileid="57" duration="100"/>
   <frame tileid="58" duration="100"/>
   <frame tileid="59" duration="100"/>
  </animation>
 </tile>
 <tile id="61">
  <animation>
   <frame tileid="61" duration="100"/>
   <frame tileid="62" duration="100"/>
   <frame tileid="63" duration="100"/>
   <frame tileid="64" duration="100"/>
   <frame tileid="65" duration="100"/>
   <frame tileid="66" duration="100"/>
   <frame tileid="67" duration="100"/>
   <frame tileid="68" duration="100"/>
  </animation>
 </tile>
 <tile id="75">
  <animation>
   <frame tileid="75" duration="100"/>
   <frame tileid="76" duration="100"/>
   <frame tileid="77" duration="100"/>
   <frame tileid="78" duration="100"/>
   <frame tileid="79" duration="100"/>
   <frame tileid="80" duration="100"/>
   <frame tileid="81" duration="100"/>
   <frame tileid="82" duration="100"/>
   <frame tileid="83" duration="100"/>
   <frame tileid="84" duration="100"/>
  </animation>
 </tile>
 <tile id="86">
  <animation>
   <frame tileid="86" duration="100"/>
   <frame tileid="87" duration="100"/>
   <frame tileid="88" duration="100"/>
   <frame tileid="89" duration="100"/>
   <frame tileid="90" duration="100"/>
   <frame tileid="91" duration="100"/>
   <frame tileid="92" duration="100"/>
   <frame tileid="93" duration="100"/>
  </animation>
 </tile>
 <tile id="100">
  <animation>
   <frame tileid="100" duration="100"/>
   <frame tileid="101" duration="100"/>
   <frame tileid="102" duration="100"/>
   <frame tileid="103" duration="100"/>
   <frame tileid="104" duration="100"/>
   <frame tileid="105" duration="100"/>
   <frame tileid="106" duration="100"/>
   <frame tileid="107" duration="100"/>
   <frame tileid="108" duration="100"/>
   <frame tileid="109" duration="100"/>
  </animation>
 </tile>
 <tile id="111">
  <animation>
   <frame tileid="111" duration="100"/>
   <frame tileid="112" duration="100"/>
   <frame tileid="113" duration="100"/>
   <frame tileid="114" duration="100"/>
   <frame tileid="115" duration="100"/>
   <frame tileid="116" duration="100"/>
   <frame tileid="117" duration="100"/>
   <frame tileid="118" duration="100"/>
  </animation>
 </tile>
 <tile id="125">
  <animation>
   <frame tileid="125" duration="100"/>
   <frame tileid="126" duration="100"/>
   <frame tileid="127" duration="100"/>
   <frame tileid="128" duration="100"/>
   <frame tileid="129" duration="100"/>
   <frame tileid="130" duration="100"/>
   <frame tileid="131" duration="100"/>
   <frame tileid="132" duration="100"/>
   <frame tileid="133" duration="100"/>
   <frame tileid="134" duration="100"/>
  </animation>
 </tile>
 <tile id="136">
  <animation>
   <frame tileid="136" duration="100"/>
   <frame tileid="137" duration="100"/>
   <frame tileid="138" duration="100"/>
   <frame tileid="139" duration="100"/>
   <frame tileid="140" duration="100"/>
   <frame tileid="141" duration="100"/>
   <frame tileid="142" duration="100"/>
   <frame tileid="143" duration="100"/>
  </animation>
 </tile>
 <tile id="175">
  <animation>
   <frame tileid="175" duration="100"/>
   <frame tileid="176" duration="100"/>
   <frame tileid="177" duration="100"/>
   <frame tileid="178" duration="100"/>
   <frame tileid="179" duration="100"/>
   <frame tileid="180" duration="100"/>
  </animation>
 </tile>
 <tile id="182">
  <animation>
   <frame tileid="182" duration="100"/>
   <frame tileid="183" duration="100"/>
   <frame tileid="184" duration="100"/>
   <frame tileid="185" duration="100"/>
   <frame tileid="186" duration="100"/>
   <frame tileid="187" duration="100"/>
   <frame tileid="188" duration="100"/>
   <frame tileid="189" duration="100"/>
   <frame tileid="190" duration="100"/>
   <frame tileid="191" duration="100"/>
  </animation>
 </tile>
 <tile id="200">
  <animation>
   <frame tileid="200" duration="100"/>
   <frame tileid="201" duration="100"/>
   <frame tileid="202" duration="100"/>
   <frame tileid="203" duration="100"/>
   <frame tileid="204" duration="100"/>
   <frame tileid="205" duration="100"/>
  </animation>
 </tile>
 <tile id="207">
  <animation>
   <frame tileid="207" duration="100"/>
   <frame tileid="208" duration="100"/>
   <frame tileid="209" duration="100"/>
   <frame tileid="210" duration="100"/>
   <frame tileid="211" duration="100"/>
   <frame tileid="212" duration="100"/>
   <frame tileid="213" duration="100"/>
   <frame tileid="214" duration="100"/>
   <frame tileid="215" duration="100"/>
   <frame tileid="216" duration="100"/>
  </animation>
 </tile>
 <tile id="225">
  <animation>
   <frame tileid="225" duration="100"/>
   <frame tileid="226" duration="100"/>
   <frame tileid="227" duration="100"/>
   <frame tileid="228" duration="100"/>
   <frame tileid="229" duration="100"/>
   <frame tileid="230" duration="100"/>
  </animation>
 </tile>
 <tile id="232">
  <animation>
   <frame tileid="232" duration="100"/>
   <frame tileid="233" duration="100"/>
   <frame tileid="234" duration="100"/>
   <frame tileid="235" duration="100"/>
   <frame tileid="236" duration="100"/>
   <frame tileid="237" duration="100"/>
   <frame tileid="238" duration="100"/>
   <frame tileid="239" duration="100"/>
   <frame tileid="240" duration="100"/>
   <frame tileid="241" duration="100"/>
  </animation>
 </tile>
 <tile id="250">
  <animation>
   <frame tileid="250" duration="100"/>
   <frame tileid="251" duration="100"/>
   <frame tileid="252" duration="100"/>
   <frame tileid="253" duration="100"/>
   <frame tileid="254" duration="100"/>
   <frame tileid="255" duration="100"/>
  </animation>
 </tile>
 <tile id="257">
  <animation>
   <frame tileid="257" duration="100"/>
   <frame tileid="258" duration="100"/>
   <frame tileid="259" duration="100"/>
   <frame tileid="260" duration="100"/>
   <frame tileid="261" duration="100"/>
   <frame tileid="262" duration="100"/>
   <frame tileid="263" duration="100"/>
   <frame tileid="264" duration="100"/>
   <frame tileid="265" duration="100"/>
   <frame tileid="266" duration="100"/>
  </animation>
 </tile>
 <tile id="275">
  <animation>
   <frame tileid="275" duration="100"/>
   <frame tileid="276" duration="100"/>
   <frame tileid="277" duration="100"/>
   <frame tileid="278" duration="100"/>
   <frame tileid="279" duration="100"/>
   <frame tileid="280" duration="100"/>
  </animation>
 </tile>
 <tile id="282">
  <animation>
   <frame tileid="282" duration="100"/>
   <frame tileid="283" duration="100"/>
   <frame tileid="284" duration="100"/>
   <frame tileid="285" duration="100"/>
   <frame tileid="286" duration="100"/>
   <frame tileid="287" duration="100"/>
   <frame tileid="288" duration="100"/>
   <frame tileid="289" duration="100"/>
   <frame tileid="290" duration="100"/>
   <frame tileid="291" duration="100"/>
  </animation>
 </tile>
 <tile id="300">
  <animation>
   <frame tileid="300" duration="100"/>
   <frame tileid="301" duration="100"/>
   <frame tileid="302" duration="100"/>
   <frame tileid="303" duration="100"/>
   <frame tileid="304" duration="100"/>
   <frame tileid="305" duration="100"/>
  </animation>
 </tile>
 <tile id="307">
  <animation>
   <frame tileid="307" duration="100"/>
   <frame tileid="308" duration="100"/>
   <frame tileid="309" duration="100"/>
   <frame tileid="310" duration="100"/>
   <frame tileid="311" duration="100"/>
   <frame tileid="312" duration="100"/>
   <frame tileid="313" duration="100"/>
   <frame tileid="314" duration="100"/>
   <frame tileid="315" duration="100"/>
   <frame tileid="316" duration="100"/>
  </animation>
 </tile>
 <tile id="350">
  <animation>
   <frame tileid="350" duration="100"/>
   <frame tileid="351" duration="100"/>
   <frame tileid="352" duration="100"/>
   <frame tileid="353" duration="100"/>
   <frame tileid="354" duration="100"/>
   <frame tileid="355" duration="100"/>
   <frame tileid="356" duration="100"/>
   <frame tileid="357" duration="100"/>
   <frame tileid="358" duration="100"/>
   <frame tileid="359" duration="100"/>
   <frame tileid="360" duration="100"/>
   <frame tileid="361" duration="100"/>
   <frame tileid="362" duration="100"/>
   <frame tileid="363" duration="100"/>
  </animation>
 </tile>
</tileset>
